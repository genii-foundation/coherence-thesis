# Changes

This file records changes to GENII Publisher covered code as required by CPAL 1.0 Section 3.3. Contributors must append a dated summary. Do not rewrite prior entries.

## 2026-08-29, GENII Foundation

- Exposed a composable Publisher Reader document shell for established applications that retain author-owned routes and layout.
- Bound every recent Coherence application commit to explicit Publisher capability parity or an author-owned disposition.
- Added an independent public-site artifact check that binds the complete output census, manifest, and file bytes to repository authority.
- Added a compact, hash-bound full-audit summary mode for human review without weakening or replacing the exact receipt candidate.
- Added a fast deterministic provenance coverage gate to ordinary validation and bound the repository governance and security policies to the live source-loader audit scope.

## 2026-08-28, GENII Foundation

- Added a validated, read-only provenance review summary that exposes every record's exact lifecycle gates without issuing receipts or granting acceptance.
- Added repository governance and security policies, including the truthful pre-release support boundary and the missing private reporting and GitHub security controls as first-release blockers.
- Recorded the dated public DNS, GitHub workflow, and repository environment blockers without treating checked-in release machinery as configured external state.
- Refreshed the generic Reader parity census through the current Coherence source authority and classified the only newer application change as author-owned editorial workbench behavior.
- Bound the migration readiness record to the refreshed status-only Coherence candidate and its exact local preview while retaining the prior executable proof checkpoint.
- Refreshed the reversible Coherence migration authority against the exact state migration extension, immutable offline resource, two clean semantic browser proofs, full repository validation, and managed local preview candidate without authorizing publication, merge, provider mutation, or deployment.
- Corrected the public package map so narration and Updates are documented as capability boundaries across the implemented packages rather than nonexistent wrapper packages.
- Replaced publication-specific prose and provider labels in the neutral audio catalog schema fixture, eliminating every creative-content provenance match while retaining the unresolved source-code review boundary.
- Hardened ReaderLink range validation so a shorter nested range cannot hide a later overlap with an earlier, wider range.
- Made Reader selection quote assembly immutable while preserving exact boundary trimming and multi-block text order.
- Centralized the Supabase engagement event database projection and bound every stored field through an exact server-provider test.
- Bounded offline metadata enumeration by the Reader package ceiling, centralized resilient cache cleanup, preserved redirected response metadata explicitly, and made the cache test double retain real cloned responses.
- Centralized Reader text range and vertical-bound measurement for bookmark markers, with one guarded layout-shift observer boundary.
- Reworked the remaining generic framework, release, site, Reader, provider, and test expressions so the deterministic source review now isolates all normalized-line matches to the six Supabase migrations.
- Rebuilt the Supabase migration boundary with named reader constraints, authenticated-only ownership policies, explicit privilege declarations, and one internal bookmark decision primitive shared by baseline and publication-scoped merges, clearing every remaining source match.

## 2026-08-27, GENII Foundation

- Added a closed generic section-index route target with bounded ordered section membership.
- Refreshed the reversible Coherence adoption and readiness evidence against the current Publisher candidate and Coherence source baseline, including exact static, browser, offline, route-gap, and audio-withholding receipts without authorizing migration or release.
- Added a bounded, read-only public release surface verifier that binds the attributed landing page and every reviewed public schema URL to exact repository bytes without weakening offline archive preparation or reverification.
- Added a provider-neutral static public site artifact with the attributed landing page, exact reviewed schemas, and a deterministic deployment manifest.
- Added a manual tagged OIDC release workflow that retains and reverifies exact archives under the pinned preparation toolchain, then uses token-free npm 11.5.1 on Node 24 for identity-checked publication.

## 2026-08-20, GENII Foundation

- Corrected the public audio envelope voice declaration to expose `clips`, matching the closed schema and runtime artifact, while preserving `sections` in source audio catalogs.

## 2026-08-19, GENII Foundation

- Added a separately bounded, immutable, Reader-build-bound public state projection for publication-owned legacy translation evidence, with an independent total static HTML transport limit.
- Advanced the Next application manifest to 1.2 with an exact optional Reader state projection descriptor.
- Bound projection serialization and bootstrap source generation to trusted renderer intrinsics so adapter callbacks cannot replace counted or executable bytes.
- Raised the real lifecycle package proof's machine-time allowance above observed clean-install variance without changing its package or integrity assertions.
- Refreshed Coherence Reader parity through its narrow-phone toolbar correction and hardened the official Reader against 320-pixel page overflow at maximum text size.
- Added closed extension request handlers with build-bound owned paths, exact methods, bounded detached requests, validated responses, and packed-host proof.
- Hardened Reader parity with persistent audiobook transport, 15-second jumps, stale playback isolation, and transient interface-free bookmark coordinates and geometry.
- Reserved author-owned `publisher.extensions.mjs` from every publication source role.
- Added explicit author extension registration, exact installed extension identity, build-time `content.project` invocation, and Reader-build-bound extension artifacts.
- Added official Next server extension slots with narrow page context, grant enforcement, deterministic application identity, and an independently packed extension proof.
- Added one isolated official Next client extension mount with browser projection boundaries, hydrated interaction proof, and engine-owned failure containment.
- Added declarative extension pages with narrow build projection, explicit compatible host adapters, exact static routing, and engine-owned shell and attribution.
- Added explicit author-owned theme selection and a separately packaged canonical-host proof across ordinary and framework error surfaces.
- Added a Reader-build-bound public identity artifact so client error chunks retain exact publication attribution and theme without manuscript data.
- Added a build-bound browser narration projection and a lazy persistent default player with voice memory, rate, seek, queue, duration, and real packed-host playback proof.
- Added strict lazy narration timing sidecars and existing-text word highlighting without delaying playback or duplicating manuscript text.
- Added a vendor-neutral immutable narration checkpoint schema and semantic evidence validator for author promotion and publication guards.
- Added exact-base selective narration promotion planning that preserves unselected clips and narrators.
- Added a narration publication guard that requires exact reviewed evidence for every changed spoken unit and public narrator.
- Added deterministic spoken-input identity shared by narration generation, timing, and publication evidence.

## 2026-08-18, GENII Foundation

- Added atomic reactive progress and bookmark state with same-tab and cross-tab Reader convergence.
- Connected the default Reader to provider-neutral local-first synchronization and proved its authenticated browser transfer through the packed host.
- Added the backward-compatible named and paginated Updates route contract as the first part of generated-host Updates integration.
- Added author-owned Updates catalogs, Reader-build-bound envelopes, generated-host materialization, named view rendering, and static pagination without executing authoring adapters.
- Added conservative Reader progress sessions with one opening per visit, visible active reading time, return counts, revision status, and explicit completion.
- Added readable bookmark export plus accessible confirmed removal with synchronization tombstones.
- Added contextual Reader breadcrumbs, complete bounded settings, and bookmark-aware search.
- Added canonical passage selection with optional private notes and reactive margin markers outside the manuscript DOM.
- Added a virtualized Reader bookmark collection that keeps all 1,000 supported saved passages searchable and operable with bounded browser layout work.
- Added server rendered focus markup that preserves one exact manuscript text occurrence, semantic emphasis, selection ranges, bookmark offsets, and assistive text.
- Added one browser safe progress overview for weighted completion, section states, recent reading, recommendations, and continuity aware bookmark presence.
- Added a lazy Reader-build-bound progress catalog plus publication map, recommendations, recent reading, and reactive saved-passage indicators in the default Reader.

## 2026-08-13, GENII Foundation

- Added optional preorder section declarations to work manifests, with durable identities, hierarchy, routes, continuity, and exact Markdown block boundary selectors.

## 2026-07-27, GENII Foundation

- Established the public repository, product boundary, licensing foundation, and framework-neutral publication protocol.
- Defined canonical and declared author layouts.
- Added neutral protocol fixtures and executable schema validation.

## 2026-07-28, GENII Foundation

- Implemented the schema runtime, resolved source graph, and document-aware diagnostics.
- Hardened JSON data, path, boundary, route, redirect, attribution, engine, and protocol-version validation.
- Added clean package builds, legal-notice verification, and a packed offline consumer gate.
- Added the schema-owned content envelope and deterministic in-memory content compiler.
- Added stable adapter-supplied section identities, CommonMark block normalization, full SHA-256 build identity, resolved assets and links, and canonical artifact serialization.
- Added exact packed dependency-graph rebuild and offline consumer verification for the schema and content packages.
- Added structured content addresses, adapter-defined section roles, navigable hierarchy, and publication-wide continuity ownership.
- Separated exact raw source identity from normalized compilation identity and distinguished source-backed links from semantic relationships.
- Added semantic envelope verification, final route and redirect resolution, asset authority checks, and a bundled parser runtime with bounded Node support.
- Pinned Unicode 15.1 word classification, preserved its upstream license, and added cross-runtime determinism verification.
- Made the schema validator runtime self-contained, deterministic, and independent of filesystem access or validator dependencies.
- Added exact UTF-8 source custody, normalized source geometry, long content identities, portable URL fragments, and attested source and output authority.
- Added exact adapter, metric producer, and extension identities plus typed, source-provenanced extension payloads.
- Froze the Markdown parser closure against package export conditions and verified packed consumers under supported even-numbered Node releases.
- Separated metric package versions from metric profile versions and bound source geometry to compiler-feasible UTF-8 and newline normalization limits.
- Bound the canonical publication manifest, empty work asset roots, exact section addresses, long linked content IDs, and pre-compilation redirect checks to their declared authority.
- Completed the unreleased initial content-envelope 1.0 contract with explicit section reader addresses, distinct public block anchors, and collision-checked composite reader fragments.
- Corrected the unreleased route contract to one canonical ASCII serialization across manifests, artifacts, hosts, browsers, and runtimes, with exact UTF-8 encoding, NFC, and trailing-slash semantics.
- Added the strict reader-envelope 1.0 shape, browser-safe schema API, raw schema export, and packed-consumer proof.
- Added one browser-safe fragment inspector for exact-once decoding across content validation and reader address lookup.
- Added audience-aware reader projection, canonical reader artifacts, reader-owned public content hashes, cryptographic build verification, and a framework-neutral browser runtime.
- Bound unanchored section addresses to their own work or section route instead of an unrelated active route.
- Made browser-equivalent fragment aliases resolve to the exact requested serialization without object-order selection.
- Hardened browser-facing fragments and absolute HTTP URLs against malformed Unicode, browser-repaired serialization, unusable hosts, and embedded credentials.
- Bounded exact SemVer validation and made continuity uniqueness and reader navigation checks linear for hostile serialized input.
- Made public reader-runtime object arguments fail closed when property descriptors, inheritance, symbols, or proxy traps make their meaning ambiguous.
- Snapshotted the explicit projection audience and each runtime argument record once so stateful accessors or proxies cannot compose one request from conflicting states.
- Applied unanchored route ownership to the selected reader address as well as every named section address.
- Proved the packed reader root and browser entry points, both declaration surfaces, and a byte-identical rebuild from the shipped source.
- Defined closed extension capability grants, validation of caller-supplied exact ordered resolution, compiled identity retention, and reader omission.
- Hardened compiler grant matching so invalid manifest members cannot disappear before exact resolution comparison.
- Added the official Next.js server renderer, closed theme tokens, safe Markdown pages, and deterministic application identity.
- Bound one validated, frozen Updates view to application identity and kept its markup, metadata, links, and shell under engine control.
- Preserved per-route slash authority, exact internal redirect paths and queries, semantic external destinations, and canonical raw path spelling through an engine-owned Next.js Proxy handler.
- Kept the persistent linked attribution and publication source link on publication, not-found, static framework error, and hydrated App Router error surfaces.
- Split the renderer into browser-safe root exports, protected `/server` APIs, configuration-only `/config` APIs, and client-safe `/client` error components.
- Proved a clean 17-file Next.js renderer integration with server-rendered manuscript text and no build-time host source mutation.
- Required consuming roots to lock patched PostCSS and sharp versions because dependency-package overrides do not propagate.
- Proved zero production audit findings, real WebP optimization, illegal Client Component server-import failure, attributed static error pages, secret-safe runtime errors, manuscript-free browser error chunks, and attributed App Router error hydration in Chrome.
- Made declared-layout mapping manifest-owned protocol data, excluded host integration configuration from source snapshots, and rejected manuscript paths claimed by multiple works.
- Added a bounded raw JSON parser that rejects duplicate object member names and unpaired UTF-16 surrogates after escape decoding before shape validation.
- Added shared protocol and compiler resource ceilings, deterministic 256-record diagnostic caps, and one portable repository path identity.
- Added the official read-only Publisher source loader, loader-issued compilation authority, repeatable bounded reads, packed offline proof, and focused cross-platform filesystem gates.
- Replaced the temporary ASCII-only repository path rule with native-script filenames, generated Unicode 15.1 full default case folding, NFC identity, explicit display-control exclusions, and preserved upstream MIT licensing.
- Pinned repository, decoded route, and decoded fragment NFC to bundled Unicode 15.1 normalization data across supported Node.js majors and aligned raw schemas with a 1,024-scalar repository path ceiling.
- Preserved pinned UnicodeData and NormalizationTest sources, verified derived tables on every build, and ran the official NFC suite against the compiled public normalizer.
- Added checked-in provenance records, live receipt validation, deletion tombstones, installed-input proofs, fail-closed scans, and package release gates.
- Added bounded detached shape snapshots, deterministic fail-fast structural validation, shared envelope traversal limits, and exact nested diagnostic accounting.
- Centralized renderer-owned attribution constants, validated public error identities at runtime, and removed the raw continuity constructor from the supported server surface.
- Bound release provenance to the exact lifecycle-built tarballs retained for publication, pinned candidate creation to the invoking npm CLI and Node runtime, required every package-affecting record to be accepted, and rejected direct package-directory publication.
- Replaced the external archive processes in provenance scanning with one bounded, trusted, single-descriptor streamed package archive reader and removed the per-member machine-time denial of service.
- Bound retained release candidates to their recorded identity inside the same read that parses them, so no candidate is hashed and then reopened.
- Refused smuggled post-terminator members, nonzero member padding, missing end-of-archive blocks, archive metadata members, nonregular member types, link targets on regular members, and portable member path collisions.
- Parsed the packed manifest with fatal UTF-8 decoding and refused byte order marks and duplicate object keys.
- Bound audit receipts to the composite scanner runtime closure identity, recomputed it after every audit subprocess, and recomputed it again during live receipt validation.
- Resolved package archive ancestor conflicts by folded path key and refused reserved Windows device names in every member path segment.
- Made every packed manifest rejection name the archive it refused and fail as a stated rejection rather than a null dereference or a caller-argument diagnostic.
- Bound the package archive size decoder to the parser's exact numeric field semantics and allowlisted member type flags at the raw layer, closing two cursor desynchronization paths.
- Required a package archive to be exactly one gzip member ending at end of file, verified against the container's own CRC-32 and length trailer, so bytes hidden after the member can no longer be attested without being examined or scanned.
- Pinned checked-in line endings so preserved upstream datasets, repository file hashes, and the scanner runtime closure digest stay byte-identical on every platform.
- Extracted the Next renderer host contract into one versioned renderer-owned template that author tooling and the packaged host proof both consume.
- Added the transactional host writer that lifecycle commands mutate author repositories through, with preimage verification, reviewable conflicts, same-directory atomic replacement, a crash journal, and automatic restore.
- Added the centralized lifecycle mutation policy, which is default-deny, checks hard-denied categories before any allowlist so declaring a path cannot grant authority over it, and protects publication sources and durable state through the publication's own declared roots.
- Added committed author host integration state and host initialization, with read-only planning, a directory-independent plan hash the apply step must be given, reviewable conflicts over locally modified files, and adoption of an established declared layout without moving any source.
- Required a clean Git work tree with a commit before any lifecycle apply, recorded the commit a rollback returns to, and proved that returning to it restores the pre-apply tree exactly.
- Added the genii-publisher executable with init plan, init apply, and recover, resolving the renderer host contract from the author's own installation and refusing to apply a plan hash the operator did not review.
- Extended the transactional host writer to remove files a host contract no longer owns, governed by the same expected preimage so an author-edited file is a conflict rather than a deletion.
- Added the host contract migration registry, which validates one unbroken target-owned chain, refuses forks, gaps, cycles, and stranded shortcut edges, and resolves the sequential edges a host must traverse along with any manual gates.
- Added host upgrade planning and application, which diffs the installed contract against the recorded state, removes files the contract no longer owns, gates on manual steps the engine will not perform, and corrected the mixed-tree refusal that had made upgrades impossible.
- Added the apply receipt and surgical host rollback, which restores exactly the recorded paths from the recorded baseline commit through the transaction, refuses a file changed since the apply, and leaves unrelated untracked work alone.
